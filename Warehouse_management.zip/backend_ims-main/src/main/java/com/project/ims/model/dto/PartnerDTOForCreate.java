package com.project.ims.model.dto;

import lombok.Data;

@Data
public class PartnerDTOForCreate {
    private String name;
    private String contactNumber;
    private String address;
}
