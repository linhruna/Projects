package com.project.ims.model.dto;

import lombok.Data;

@Data
public class PartnerDTO {
    private int partnerID;
    private String name;
}
