package com.project.ims.model.dto;
import lombok.Data;
@Data
public class SupplierDTOForAddProduct {
			
	    private int supplierId;
	    private int productId;
	}

